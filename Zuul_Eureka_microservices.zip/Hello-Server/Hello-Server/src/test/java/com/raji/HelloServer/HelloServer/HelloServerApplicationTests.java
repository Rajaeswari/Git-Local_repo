package com.raji.HelloServer.HelloServer;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class HelloServerApplicationTests {

	@Test
	public void contextLoads() {
	}

}
